# main_dashboard.py
import streamlit as st
import pandas as pd
import plotly.express as px
import json, os
from streamlit_autorefresh import st_autorefresh

st.set_page_config("Quant Option Chain", layout="wide")
st.title("📈 Option Chain Dashboard — NIFTY Only")

# Auto refresh
st_autorefresh(interval=5000, key="refresh")

# Load ticks
DATA_DIR = "./ticks"
files = sorted([f for f in os.listdir(DATA_DIR) if f.endswith(".json")])
data = []

for f in files:
    with open(os.path.join(DATA_DIR, f)) as j:
        d = json.load(j)
    symbol = d['instrument']['symbol']
    if not symbol.startswith("NIFTY"):
        continue
    strike = int("".join(filter(str.isdigit, symbol)))
    data.append({
        "Symbol": symbol,
        "Type": "CE" if "CE" in symbol else "PE",
        "Strike": strike,
        "LTP": d["ltp"],
        "OI": d["oi"],
        "COI": d["change_in_oi"],
        "Volume": d["volume_by_product"]
    })

if not data:
    st.warning("No live NIFTY data found.")
    st.stop()

raw = pd.DataFrame(data)
ce = raw[raw.Type == "CE"].set_index("Strike")
pe = raw[raw.Type == "PE"].set_index("Strike")
strikes = sorted(set(ce.index).union(pe.index))

spot_candidates = [ce.loc[k]['LTP'] + pe.loc[k]['LTP'] for k in ce.index if k in pe.index]
atm_strike = min(ce.index, key=lambda k: abs(ce.loc[k]['LTP'] + pe.loc[k]['LTP'] - max(spot_candidates))) if spot_candidates else strikes[len(strikes)//2]

st.sidebar.header("🔎 Filters")
offset = st.sidebar.slider("Strikes ± Around ATM", 5, 20, 10)
min_oi = int(st.sidebar.number_input("Min OI", value=0))
min_vol = int(st.sidebar.number_input("Min Volume", value=0))
view_mode = st.sidebar.radio("View Mode", ["LTP View", "Greeks View", "All Columns"])

min_strike = atm_strike - offset * 50
max_strike = atm_strike + offset * 50

rows = []
max_oi = max(raw.OI.max(), 1)
for strike in strikes:
    if not (min_strike <= strike <= max_strike): continue
    ce_row = ce.loc[strike] if strike in ce.index else {}
    pe_row = pe.loc[strike] if strike in pe.index else {}
    if ce_row.get("OI", 0) < min_oi and pe_row.get("OI", 0) < min_oi: continue
    if ce_row.get("Volume", 0) < min_vol and pe_row.get("Volume", 0) < min_vol: continue
    rows.append({
        "CE_IV": "-", "CE_OI": ce_row.get("OI"), "CE_Vol": ce_row.get("Volume"),
        "CE_LTP": ce_row.get("LTP"), "Strike": strike, "PE_LTP": pe_row.get("LTP"),
        "PE_Vol": pe_row.get("Volume"), "PE_OI": pe_row.get("OI"), "PE_IV": "-"
    })

if not rows:
    st.warning("No data matches your filters.")
else:
    df = pd.DataFrame(rows)
    top_puts = df.nlargest(1, "PE_OI")
    top_calls = df.nlargest(1, "CE_OI")
    styled_df = df.style.format("{:.2f}", na_rep="-")
    for col in ["CE_OI", "PE_OI"]:
        styled_df = styled_df.bar(subset=[col], color="#85C1E9", vmin=0, vmax=max_oi)

    if view_mode == "LTP View":
        st.dataframe(df[["CE_LTP", "Strike", "PE_LTP"]])
    elif view_mode == "Greeks View":
        st.dataframe(df[["CE_IV", "Strike", "PE_IV"]])
    else:
        st.dataframe(styled_df, use_container_width=True)

    fig = px.line(df, x="Strike", y=["CE_LTP", "PE_LTP"], markers=True)
    fig.add_vline(x=atm_strike, line_dash="dash", line_color="blue", annotation_text="ATM")
    if not top_puts.empty:
        fig.add_vline(x=top_puts.iloc[0]['Strike'], line_color="green", annotation_text="Support")
    if not top_calls.empty:
        fig.add_vline(x=top_calls.iloc[0]['Strike'], line_color="red", annotation_text="Resistance")
    fig.update_layout(title="LTP vs Strike (ATM & S/R)", xaxis_title="Strike Price", yaxis_title="LTP")
    st.plotly_chart(fig, use_container_width=True)
